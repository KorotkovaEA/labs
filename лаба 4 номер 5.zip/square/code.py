a = 15

def square_perimeter(side_a = a):
    return side_a * 4

def square_area(side_a = a):
    return side_a ** 2
