from .code import square_area, square_perimeter
