from .code import triangle_area, triangle_perimeter
